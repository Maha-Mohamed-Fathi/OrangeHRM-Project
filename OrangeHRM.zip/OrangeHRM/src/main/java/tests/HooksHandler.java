package tests;

import driver.WebDriverSingleton;
import io.cucumber.java.After;
import io.cucumber.java.Before;

import java.io.IOException;

public class HooksHandler extends BaseTest {

    @Before(value = "@OrangeHRM", order = 1)
    public void initialize() throws InterruptedException {
        webDriver = WebDriverSingleton.getDriverSingleton();
        webDriver.resetCache();
        webDriver.navigateTo("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }

//    @After(value = "@OrangeHRM")
//    public void tearDown() throws InterruptedException {
//        webDriver.resetCache();
//        closeWebDriverAfterAllTestsHook();
//    }
//
//    private void closeWebDriverAfterAllTestsHook() {
//        Runtime.getRuntime().addShutdownHook(new Thread(WebDriverSingleton::close));
//
//    }


}
