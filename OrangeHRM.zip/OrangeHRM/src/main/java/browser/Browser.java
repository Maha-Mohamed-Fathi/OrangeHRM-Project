package browser;

import platform.OrangeHRM;

public class Browser {
    public OrangeHRM orangeHRM;

    public Browser(){
        orangeHRM =new OrangeHRM();}
}
