package pages;

import org.openqa.selenium.By;


public class HomePage extends BasePage {
    private final By adminButton = By.xpath("//a[@href='/web/index.php/admin/viewAdminModule']");
    private final By timeButtom = By.xpath("//a[@href='/web/index.php/time/viewTimeModule']");




    public void clickOnAdmin() {
        waitUntilElementIsPresent(adminButton).click();
    }
    public void clickOnTime()  {
        waitUntilElementIsPresent(timeButtom).click();

    }





    public AdminPage goToAdmin(){

        return new AdminPage();
    }
    public EmployeePage goToEmployee(){

        return new EmployeePage();
    }



}
