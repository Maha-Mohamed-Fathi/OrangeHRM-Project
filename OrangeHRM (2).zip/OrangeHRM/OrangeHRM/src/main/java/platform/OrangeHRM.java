package platform;

import pages.AdminPage;
import pages.EmployeePage;
import pages.HomePage;
import pages.LoginPage;


public class OrangeHRM {
    public LoginPage login;
    public HomePage home;
    public AdminPage admin;
    public EmployeePage employee;


    public OrangeHRM(){
        login = new LoginPage();
    }
}
