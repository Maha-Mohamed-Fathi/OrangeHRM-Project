package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


public class EmployeePage extends BasePage {
    private final By employeeNameText = By.xpath("//p[@class='oxd-userdropdown-name']");
    private final By editButton = By.xpath("//button[contains(.,' Edit ')]");
    private final By projectTextField = By.xpath("(//table/tbody/tr/td[1])[1]");
    private final By activityListArrow = By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']");
    private final By firstDayTextField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]");
    private final By secondDayTextField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[3]");
    private final By thirdDayTextField = By.xpath("(//input[@class='oxd-input oxd-input--active'])[4]");
    private final By totalHoursText = By.xpath("(//td[@class='orangehrm-timesheet-table-body-cell --center --freeze-right --highlight'])[1]");
    private final By saveButton = By.xpath("//button[@type ='submit']");
    private final By submitButton = By.xpath("//button[contains(.,' Submit ')]");
    private final By employeeProfile = By.className("oxd-userdropdown-tab");
    private final By logoutButton = By.xpath("//a[@href='/web/index.php/auth/logout']");
    private final By sheetStatusText = By.xpath("//p[@class='oxd-text oxd-text--p oxd-text--subtitle-2']");

    public void getEmployeeName(String employeeName) {
        waitUntilElementIsPresent(employeeNameText);
        Assert.assertEquals(employeeName, driver.findElement(employeeNameText).getText());
    }


    public void clickOnEditButton() {
        waitUntilElementIsPresent(editButton).click();
    }

    public void enterProject(String projectName) throws InterruptedException {
        waitUntilElementIsPresent(projectTextField);
        driver.findElement(projectTextField).click();
        Actions actions = new Actions(driver);
        actions.sendKeys(driver.findElement(projectTextField), projectName).perform();
        Thread.sleep(2000);
        actions.sendKeys(driver.findElement(projectTextField), Keys.ARROW_DOWN).perform();
        Thread.sleep(2000);
        actions.sendKeys(driver.findElement(projectTextField), Keys.ENTER).perform();

    }

    public void selectActivity(String activity) throws InterruptedException {
        int indexOfSelectedStatus;
        waitUntilElementIsClickable(activityListArrow).click();
        if (activity.equalsIgnoreCase("Bug Fixes")) {
            indexOfSelectedStatus = 2;
        } else if (activity.equalsIgnoreCase("Feature Development")) {
            indexOfSelectedStatus = 3;
        } else if (activity.equalsIgnoreCase("Implementation")) {
            indexOfSelectedStatus = 4;
        } else if (activity.equalsIgnoreCase("Project Management")) {
            indexOfSelectedStatus = 5;
        } else if (activity.equalsIgnoreCase("QA Testing")) {
            indexOfSelectedStatus = 6;
        } else if (activity.equalsIgnoreCase("Requirement Gathering")) {
            indexOfSelectedStatus = 7;
        } else if (activity.equalsIgnoreCase("Support & Maintenance")) {
            indexOfSelectedStatus = 8;
        } else {
            indexOfSelectedStatus = 9;
        }
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//div[@role='listbox']//child::div)[" + indexOfSelectedStatus + "]")).click();


    }

    public void enterFirstDayTime(String time) {
        waitUntilElementIsPresent(firstDayTextField);
        driver.findElement(firstDayTextField).sendKeys(time);
    }

    public void enterSecondDayTime(String time) {
        waitUntilElementIsPresent(secondDayTextField);
        driver.findElement(secondDayTextField).sendKeys(time);
    }

    public void enterThirdDayTime(String time) {
        waitUntilElementIsPresent(thirdDayTextField);
        driver.findElement(thirdDayTextField).sendKeys(time);
    }

    public void clickOnSaveButton() {
        waitUntilElementIsPresent(saveButton).click();
    }

    public void getTotalHours(String totalHours) {
        waitUntilElementIsPresent(totalHoursText);
        Assert.assertEquals(totalHours, driver.findElement(totalHoursText).getText());
    }

    public void clickOnSubmitButton() {
        waitUntilElementIsPresent(submitButton).click();
    }

    public void clickOnEmployeeProfile() {
        waitUntilElementIsPresent(employeeProfile);
        driver.findElement(employeeProfile).click();
    }

    public void clickOnLogoutButton() {
        waitUntilElementIsPresent(logoutButton);
        driver.findElement(logoutButton).click();
    }
    public void getSheetStatus(String sheetStatus) throws InterruptedException {
        waitUntilElementIsPresent(sheetStatusText);
        Thread.sleep(2000);
        Assert.assertEquals(sheetStatus, driver.findElement(sheetStatusText).getText());
    }
}
