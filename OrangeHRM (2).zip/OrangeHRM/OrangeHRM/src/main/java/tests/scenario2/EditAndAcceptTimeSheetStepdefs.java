package tests.scenario2;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import tests.BaseTest;

public class EditAndAcceptTimeSheetStepdefs extends BaseTest {
    @Given("Employee login with {string} and {string} to OrangeHRM login page")
    public void employeeLoginWithAndToOrangeHRMLoginPage(String employeeUsername, String employeePassword) {
        browser.orangeHRM.login.enterUsername(employeeUsername);
        browser.orangeHRM.login.enterPassword(employeePassword);
        browser.orangeHRM.login.clickOnLoginButton();
    }

    @And("Click on Time")
    public void clickOnTime() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.home = browser.orangeHRM.login.goHome();
        browser.orangeHRM.home.clickOnTime();
    }

    @And("Click on Edit button")
    public void clickOnEditButton() {
        browser.orangeHRM.employee = browser.orangeHRM.home.goToEmployee();
        browser.orangeHRM.employee.clickOnEditButton();
    }

    @And("Enter project name with {string}")
    public void enterProjectNameWith(String projectName) throws InterruptedException {
        browser.orangeHRM.employee.enterProject(projectName);

    }

    @And("Select Activity with {string}")
    public void selectActivityWith(String activity) throws InterruptedException {

        browser.orangeHRM.employee.selectActivity(activity);
    }

    @And("Enter First Day Time with{string}, Second Day Time with{string} and Third Day Time with{string}")
    public void enterFirstDayTimeWithSecondDayTimeWithAndThirdDayTimeWith(String timeOne, String timeTwo, String timeThree) {
        browser.orangeHRM.employee.enterFirstDayTime(timeOne);
        browser.orangeHRM.employee.enterSecondDayTime(timeTwo);
        browser.orangeHRM.employee.enterThirdDayTime(timeThree);
    }

    @Then("Confirm that total hours is {string}")
    public void confirmThatTotalHoursIs(String totalHours) {
      browser.orangeHRM.employee = browser.orangeHRM.home.goToEmployee();
      browser.orangeHRM.employee.getTotalHours(totalHours);
    }

    @And("Click on Save Button in Employee Page")
    public void clickOnSaveButtonInEmployeePage() {
        browser.orangeHRM.employee.clickOnSaveButton();
    }

    @And("Click on Submit Button")
    public void clickOnSubmitButton() {
        browser.orangeHRM.employee.clickOnSubmitButton();
    }

    @And("Click on Employee Profile")
    public void clickOnEmployeeProfile() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.employee.clickOnEmployeeProfile();
    }

    @And("Click on Logout Button for Employee")
    public void clickOnLogoutButtonForEmployee() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.employee.clickOnLogoutButton();
    }

    @And("Search for Employee name {string} and click on view button")
    public void searchForEmployeeNameAndClickOnViewButton(String employeeName) throws InterruptedException {
        browser.orangeHRM.admin = browser.orangeHRM.home.goToAdmin();
        browser.orangeHRM.admin.enterEmployeeName(employeeName);
        browser.orangeHRM.admin.clickOnSaveButton();
    }


    @Then("Click on Approve Button")
    public void clickOnApproveButton() throws InterruptedException {
        browser.orangeHRM.admin.clickOnApproveButton();
    }

    @Then("Validate that time sheet approved with {string}")
    public void validateThatTimeSheetApprovedWith(String sheetStatus) throws InterruptedException {
        browser.orangeHRM.employee= browser.orangeHRM.home.goToEmployee();
        browser.orangeHRM.employee.getSheetStatus(sheetStatus);
    }
}
