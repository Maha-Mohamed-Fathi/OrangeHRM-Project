package tests.scenario1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import tests.BaseTest;

public class CreateNewUserStepdefs extends BaseTest {


    @Given("Admin login with {string} and {string} to OrangeHRM login page")
    public void adminLoginWithAndToOrangeHRMLoginPage(String adminUsername, String adminPassword) throws InterruptedException {
        browser.orangeHRM.login.enterUsername(adminUsername);
        browser.orangeHRM.login.enterPassword(adminPassword);
        browser.orangeHRM.login.clickOnLoginButton();
    }
    

    @And("Click on Admin")
    public void clickOnAdmin() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.home = browser.orangeHRM.login.goHome();
        browser.orangeHRM.home.clickOnAdmin();
    }

    @And("Click on Add button")
    public void clickOnAddButton() {
        browser.orangeHRM.admin = browser.orangeHRM.home.goToAdmin() ;
        browser.orangeHRM.admin.clickOnAddButton();
    }

    @And("Select User Role with {string}")
    public void selectUserRoleWith(String userRole) {
        browser.orangeHRM.admin.selectUserRole(userRole);
    }

    @And("Enter employee name with {string}")
    public void enterEmployeeNameWith(String employeeName) throws InterruptedException {
        browser.orangeHRM.admin.enterEmployeeName(employeeName);
    }

    @And("Select Status with {string}")
    public void selectStatusWith(String status) {
        browser.orangeHRM.admin.selectStatus(status);
    }

    @And("Enter Username with{string}")
    public void enterUsernameWith(String username) throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.admin.enterUsername(username);
    }

    @And("Enter Password with{string}")
    public void enterPasswordWith(String password) throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.admin.enterPassword(password);

    }

    @And("Enter Confirmed Password with{string}")
    public void enterConfirmedPasswordWith(String confirmedPassword) throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.admin.enterConfirmedPassword(confirmedPassword);

    }

    @Then("Click on Save Button")
    public void clickOnSaveButton() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.admin.clickOnSaveButton();
    }

    @And("Click on Logout Button")
    public void clickOnLogoutButton() throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.admin.clickOnLogoutButton();
    }

    @Then("Login with New User with {string} and {string} to OrangeHRM login page")
    public void loginWithNewUserWithAndToOrangeHRMLoginPage(String employeeUsername, String employeePassword) throws InterruptedException {
        Thread.sleep(2000);
        browser.orangeHRM.login.enterUsername(employeeUsername);
        browser.orangeHRM.login.enterPassword(employeePassword);
        browser.orangeHRM.login.clickOnLoginButton();
    }

    @When("Confirm that New User logged in successfully from {string}")
    public void confirmThatNewUserLoggedInSuccessfullyFrom(String employeeName) throws InterruptedException {
        Thread.sleep(2000);

        browser.orangeHRM.employee = browser.orangeHRM.home.goToEmployee() ;
        browser.orangeHRM.employee.getEmployeeName(employeeName);
    }
}
