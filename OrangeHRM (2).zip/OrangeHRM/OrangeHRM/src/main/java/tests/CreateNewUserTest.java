package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CreateNewUserTest extends BaseTest {

    @Test(priority = 1)

    public void loginAsAdmin() throws InterruptedException {

        webDriver.navigateTo("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        browser.orangeHRM.login.enterUsername("Admin");
        browser.orangeHRM.login.enterPassword("admin123");
        browser.orangeHRM.login.clickOnLoginButton();
        Thread.sleep(2000);

    }

    @Test(priority = 2)
    public void clickOnAdmin() {
        browser.orangeHRM.home = browser.orangeHRM.login.goHome();
        browser.orangeHRM.home.clickOnAdmin();

//        browser.orangeHRM.home.enterSearchItem("samsung ");
//        browser.orangeHRM.home.clickOnSearchResult();
    }

//
//    @Test(priority = 3)
//    public void getItem() throws InterruptedException {
//        browser.orangeHRM.categories = browser.orangeHRM.home.goToProducts();
//        browser.orangeHRM.categories.clickOnCategoryTab();
//        Thread.sleep(2000);
//
//        browser.orangeHRM.categories.clickOnItem();
//        browser.orangeHRM.product = browser.orangeHRM.categories.goToProduct();
//        browser.orangeHRM.product.choose();
//    }
//
//    @Test
//    public void goToCartPage() throws InterruptedException {
//        browser.orangeHRM.cart = browser.orangeHRM.product.goToCart();
//        browser.orangeHRM.cart.clickOnCartButton();
//        browser.orangeHRM.cart.clickOnCheckoutButton();
//        browser.orangeHRM.cart.clickOnNewAddressButton();
//    }
//
//    @Test
//
//
//    public void enterAddressDetails() throws InterruptedException {
//        browser.orangeHRM.cart.chooseCity();
//        browser.orangeHRM.cart.chooseDistrict();
//        Thread.sleep(1000);
//        browser.orangeHRM.cart.enterStreetName("main ST");
//        browser.orangeHRM.cart.enterBuildingNo("abcdefg");
//        Assert.assertEquals(browser.orangeHRM.cart.getBuildingNoErrorHint(), "Max characters allowed: 4 ");
//        browser.orangeHRM.cart.enterFloorNo("efghjpg");
//        Assert.assertEquals(browser.orangeHRM.cart.getFloorNoErrorHint(), "Max characters allowed: 4 ");
//        browser.orangeHRM.cart.enterAppartmentNo("qwertyuiop[pkjhgfdgh");
//        Assert.assertEquals(browser.orangeHRM.cart.getApartmentNoErrorHint(), "Max characters allowed: 10 ");
//        Assert.assertEquals(browser.orangeHRM.cart.getSaveAddressButtonStatus(), "disabled");
//    }
}
